 mensagem = (msg) => alert(msg);
   soma = (a,b) => a + b;


/*
// f(x) = 2x + 2
// f(2) = 2.2 + 2
// f(2) = 6
*/
